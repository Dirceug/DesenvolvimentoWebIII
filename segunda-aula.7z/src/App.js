import './App.css';
import Cadastro from './components/Cadastro';

function App() {
  return (
    <Cadastro/>
  );
}

export default App;
