import { useState } from 'react';

function Cadastro() {
    const [tarefas, setTarefas] = useState(
        [
            "Pagar a conta de luz",
            "Estudar Programação",
            "Enviar a tarefa"
        ]
    );
    const [input, setInput] = useState('')

    function handleRegistro(e){

    }

    return (
        <div>
            <h1>Cadastro de Tarefas</h1>
            <form onSubmit={handleRegistro} >
                <label>Nome da Tarefa: </label><br/>
                <input
                    placeholder="Digite uma tarefa"
                    // value={tarefas}
                    onChange={ (e) => setTarefas(e.target.value)}
                /><br/>           
                <button type='submit' >Registro</button><br/><br/>
            </form><br/><br/>

            <ul>
                {tarefas.map( tarefa => (
                    <li>{tarefa}</li>
                ) )}
            </ul>

            <div>
            </div>
        </div>
    );
}

export default Cadastro;